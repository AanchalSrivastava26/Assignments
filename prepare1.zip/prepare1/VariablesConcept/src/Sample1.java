
public class Sample1 {
	 int num1,num2;
	static int result2;
	static int result;


	public Sample1(int num1, int num2) {
		super();
		this.num1 = num1;
		this.num2 = num2;
		
		num1++;
		num2++;
		result=num1+num2;

	}
public int add(int num3,int num4) {
	result2=num3+num4;
	return result2;
	
}

	public void display() {
		System.out.println("result="+result);
	}
	public void display2() {
		System.out.println("result="+result2);
	}


	public static void main(String[] args) {
		Sample1 s1=new Sample1(10,20);
		
		s1.display();
		s1.add(30,40);
		s1.display2();
	
		



	}

}
