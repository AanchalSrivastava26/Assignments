package com.cg.inheritanceDemo.beans;

public class CEmployee extends Employee{
	private int variablePay,hrs;



	public CEmployee(int employeeId, int basicSalary, String firstName, String lastName, int hrs) {
		super(employeeId, basicSalary, firstName, lastName);
		this.hrs=hrs;
	
	}
 public int getHrs() {
		return hrs;
	}

	public void setHrs(int hrs) {
		this.hrs = hrs;
	}
	public void signContract() {
		System.out.println("contract has signed");
	}
	public void calculateSalary() {
		variablePay=hrs*100;
		setTotalSalary(variablePay);
	}

	
	

}
