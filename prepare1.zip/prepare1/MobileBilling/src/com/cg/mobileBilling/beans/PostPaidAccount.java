package com.cg.mobileBilling.beans;

public class PostPaidAccount {
	private int mobileNo;
	private Bill bill[]=new Bill[10];
	private Address address;
	public PostPaidAccount() {
		
	}
	public PostPaidAccount(int mobileNo, Bill[] bill, Address address) {
		super();
		this.mobileNo = mobileNo;
		this.bill = bill;
		this.address = address;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public Bill[] getBill() {
		return bill;
	}
	public void setBill(Bill[] bill) {
		this.bill = bill;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	



}
