
public class AddBinaryNumbers {

	public static void main(String[] args) {
		int n1[]= {0,1,0,1,1};
		int n2[]= {1,0,1,1,0};
		int carry=0;
		int result[]=new int[5];
		for(int i=0;i<5;i++) {
			if(n1[i]==0 && n2[i]==1)
				result[i]=1;
			else if(n1[i]==1 || n2[i]==1) {
				result[i]=0;
				carry=1;
			}else
				result[i]=0;
		}
		for(int i=0;i<5;i++) {

System.out.print(result[i]);
		}
		

	}

}
