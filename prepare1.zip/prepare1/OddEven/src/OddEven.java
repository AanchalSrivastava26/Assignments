public class OddEven {
	public static void main(String[] args) {
		int i,temp,sum;
		System.out.println("even numbers");
		for(i=1;i<=6;i++){
			if(i%2==0)
				System.out.print(i+" ");
		}
		System.out.println("odd numbers");
		for(i=1;i<=6;i++){
			if(i%2!=0)
				System.out.print(i+" ");
		}
		System.out.println("Palindrome numbers");

		for(i=1;i<=200;i++){
			sum=0;
			temp=i;

			while(temp>0){
				sum=sum*10+temp%10;
				temp=temp/10;
			}
			if(sum==i)
				System.out.print(i+" ");}
				System.out.println("Armstrong numbers");

		for(i=1;i<=200;i++){
			sum=0;
			temp=i;

			while(temp>0){
			int r=temp%10;
				sum=sum+r*r*r;
				temp=temp/10;
			}
			if(sum==i)
				System.out.print(i+" ");}


	}}
