
public class Quadratic {
	public static void main(String[] args) {
		int i,sum,temp;
		for(i=1;i<=500;i++){
		temp=i;
		sum=0;
			while(temp>0){
sum=sum*10+temp%10;
temp=temp/10;
}
if(i==sum)
	System.out.print(i+" ");}
		}

	}

