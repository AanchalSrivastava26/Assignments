public class ThirdLargest{
	public static void main(String[] args){
		int i,j,a[]={3,2,1,4,6};
		for(i=0;i<5;i++){
			for(j=i+1;j<5;j++){
				if(a[i]>a[j]){
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		System.out.println("array after sort");
		for(i=0;i<5;i++){
		System.out.println(a[i]);
	    }
     System.out.println("Third largest elememt="+(a[2]));
	}
}
