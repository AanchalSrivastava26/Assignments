public class Pattern10{
	public static void main(String[] args){
		int i,j,k;
		for(i=0;i<5;i++){
		int c=65;
			for(j=0;j<i;j++){
				System.out.print((char)c);
				c++;
			}
			
			System.out.println(" ");
		}
	}
}