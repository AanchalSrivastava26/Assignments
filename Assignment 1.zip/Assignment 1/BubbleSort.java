public class BubbleSort{
	public static void main(String[] args){
		int a[]={1,2,4,2}, i,j;
		for(i=0;i<3;i++){
			for(j=0;j<4-i-1;j++){
				if(a[j]>a[j+1]){
					int temp=a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
			}
		}
		for(i=0;i<4;i++){
			System.out.print(a[i]);
		}
	}
}
