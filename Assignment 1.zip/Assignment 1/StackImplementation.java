public class StackImplementation {
	private int maxSize;
	private long[] stackArray;
	private int top;

	public StackImplementation(int s) {
		maxSize=s;
		stackArray=new long[maxSize];
		top=-1;
	}
	public void push(long j) {
		stackArray[++top]=j;
	}
	public long pop() {
		return stackArray[top--];
	}
	public long peek() {
		return stackArray[top];
	}
	public boolean isEmpty() {
		return (top==-1);

	}
	public boolean isFull() {
		return (top==maxSize-1);
	}

	public static void main(String[] args) {

		StackImplementation si=new StackImplementation(10);
		si.push(10);
		si.push(20);
		si.push(30);
		si.push(40);
		si.push(50);
		while(!si.isEmpty()) {
			long value=si.pop();
			System.out.print(value);
			System.out.print(" ");
		}
		System.out.println("");
	}

}
