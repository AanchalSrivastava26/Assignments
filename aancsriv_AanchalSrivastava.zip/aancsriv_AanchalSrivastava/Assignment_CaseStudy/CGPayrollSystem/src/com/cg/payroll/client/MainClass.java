package com.cg.payroll.client;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;

public class MainClass {

	public static void main(String[] args) {
		Associate associate=new Associate();
		associate.setAssociateID(200);
		associate.setYearlyInvestmentUnder80C(10000);
		associate.setLastName("Srivastava");
		associate.setFirstName("Aanchal");
		associate.setDepartment("JEE");
		associate.setDesignation("trainee");
		associate.setPancard("ABCD1234");
		associate.setEmailId("abc123@gmail.com");
		System.out.println(associate.getAssociateID()+" "+associate.getFirstName()+" "+associate.getLastName()+" "+
				associate.getYearlyInvestmentUnder80C()+" "+associate.getDepartment()+" "+associate.getDesignation()+" "+
				associate.getPancard()+" "+associate.getEmailId());
		BankDetails bd=new BankDetails();
		bd.setAccountNumber(12345678);
		bd.setBankName("HDFC");
		bd.setIfscCode("HDFC001010");
		System.out.println(bd.getAccountNumber()+" "+bd.getBankName()+" "+bd.getIfscCode());

		Salary s=new Salary();
		s.setBasicSalary(10000);
		s.setHra(1000);
		s.setConveyanceAllowance(3000);
		s.setOtherAllowance(2000);
		s.setPersonalAllowance(2000);
		s.setMonthlyTax(200);
		s.setEpf(100);
		s.setCompanyPf(100);
		s.setGratuity(200);
		s.setGrossSalary(3000);
		s.setNetSalary(15000);
		System.out.println(s.getBasicSalary()+" "+s.getHra()+" "+s.getConveyanceAllowance()+" "+
				s.getOtherAllowance()+" "+s.getPersonalAllowance()+" "+s.getMonthlyTax()+" "+
				s.getEpf()+" "+s.getCompanyPf()+" "+s.getGratuity()+" "+s.getGrossSalary()+" "+s.getNetSalary());

	}

}
