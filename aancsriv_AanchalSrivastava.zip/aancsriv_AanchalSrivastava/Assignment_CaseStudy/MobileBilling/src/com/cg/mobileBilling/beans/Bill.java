package com.cg.mobileBilling.beans;

public class Bill {
	private String billID,billMonth;
	private int noOfLocalSMS,NOoFsTDsms,noOfLocalCalls,noOfStdCalls,internetDataUsageUnits,internetDataUsageUnitsAmount,stateGST,centralGST,totalBillAmount,totalSMSAmount,stdSMSAmount,localCallAmount;
	public Bill(String billID, String billMonth, int noOfLocalSMS, int nOoFsTDsms, int noOfLocalCalls, int noOfStdCalls,
			int internetDataUsageUnits, int internetDataUsageUnitsAmount, int stateGST, int centralGST,
			int totalBillAmount, int totalSMSAmount, int stdSMSAmount, int localCallAmount) {
		super();
		this.billID = billID;
		this.billMonth = billMonth;
		this.noOfLocalSMS = noOfLocalSMS;
		NOoFsTDsms = nOoFsTDsms;
		this.noOfLocalCalls = noOfLocalCalls;
		this.noOfStdCalls = noOfStdCalls;
		this.internetDataUsageUnits = internetDataUsageUnits;
		this.internetDataUsageUnitsAmount = internetDataUsageUnitsAmount;
		this.stateGST = stateGST;
		this.centralGST = centralGST;
		this.totalBillAmount = totalBillAmount;
		this.totalSMSAmount = totalSMSAmount;
		this.stdSMSAmount = stdSMSAmount;
		this.localCallAmount = localCallAmount;
	}
	public String getBillID() {
		return billID;
	}
	public void setBillID(String billID) {
		this.billID = billID;
	}
	public String getBillMonth() {
		return billMonth;
	}
	public void setBillMonth(String billMonth) {
		this.billMonth = billMonth;
	}
	public int getNoOfLocalSMS() {
		return noOfLocalSMS;
	}
	public void setNoOfLocalSMS(int noOfLocalSMS) {
		this.noOfLocalSMS = noOfLocalSMS;
	}
	public int getNOoFsTDsms() {
		return NOoFsTDsms;
	}
	public void setNOoFsTDsms(int nOoFsTDsms) {
		NOoFsTDsms = nOoFsTDsms;
	}
	public int getNoOfLocalCalls() {
		return noOfLocalCalls;
	}
	public void setNoOfLocalCalls(int noOfLocalCalls) {
		this.noOfLocalCalls = noOfLocalCalls;
	}
	public int getNoOfStdCalls() {
		return noOfStdCalls;
	}
	public void setNoOfStdCalls(int noOfStdCalls) {
		this.noOfStdCalls = noOfStdCalls;
	}
	public int getInternetDataUsageUnits() {
		return internetDataUsageUnits;
	}
	public void setInternetDataUsageUnits(int internetDataUsageUnits) {
		this.internetDataUsageUnits = internetDataUsageUnits;
	}
	public int getInternetDataUsageUnitsAmount() {
		return internetDataUsageUnitsAmount;
	}
	public void setInternetDataUsageUnitsAmount(int internetDataUsageUnitsAmount) {
		this.internetDataUsageUnitsAmount = internetDataUsageUnitsAmount;
	}
	public int getStateGST() {
		return stateGST;
	}
	public void setStateGST(int stateGST) {
		this.stateGST = stateGST;
	}
	public int getCentralGST() {
		return centralGST;
	}
	public void setCentralGST(int centralGST) {
		this.centralGST = centralGST;
	}
	public int getTotalBillAmount() {
		return totalBillAmount;
	}
	public void setTotalBillAmount(int totalBillAmount) {
		this.totalBillAmount = totalBillAmount;
	}
	public int getTotalSMSAmount() {
		return totalSMSAmount;
	}
	public void setTotalSMSAmount(int totalSMSAmount) {
		this.totalSMSAmount = totalSMSAmount;
	}
	public int getStdSMSAmount() {
		return stdSMSAmount;
	}
	public void setStdSMSAmount(int stdSMSAmount) {
		this.stdSMSAmount = stdSMSAmount;
	}
	public int getLocalCallAmount() {
		return localCallAmount;
	}
	public void setLocalCallAmount(int localCallAmount) {
		this.localCallAmount = localCallAmount;
	}


}
