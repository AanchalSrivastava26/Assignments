package com.cg.mobileBilling.client;


import com.cg.mobileBilling.beans.Address;
import com.cg.mobileBilling.beans.Bill;
import com.cg.mobileBilling.beans.Customer;
import com.cg.mobileBilling.beans.Plan;
import com.cg.mobileBilling.beans.PostPaidAccount;


public class MainClass {

	public static void main(String[] args) {
   		Address ad=new Address("Lucknow","Uttar Pradesh","India",123457);
			System.out.println(ad.getCity()+" "+ad.getState()+" "+ad.getCountry()+" "+ad.getPinCode());

		Bill b=new Bill("abc123","january",190,200,234,123,453,233,120,120,200,120,123,456);
			System.out.println(b.getBillID()+" "+b.getBillMonth+" "+b.getNoOfLocalSMS+" "+b.getNOoFsTDsms+b.getNoOfLocalCalls+" "+b.getNoOfStdCalls+" "+
				b.getInternetDataUsageUnits+" "+b.getInternetDataUsageUnitsAmount+" "+b.getStateGST+" "+b.getCentralGST+" "+
				b.getTotalBillAmount+" "+b.getTotalSMSAmount+" "+b.getStdSMSAmount+" "+b.getLocalCallAmount);

		Customer c=new Customer("aancsriv","aanchal", "srivastava", "1234567", "abc123@gmail.com", "1234adfgj", "26-sep-1996", 1234567);
			System.out.println(c.getCustomerId()+" "+c.getFirstName()+" "+c.getLastName()+" "+
				c.getMobileNo()+" "+c.getEmailId()+" "+c.getPancardNo()+" "+c.getDateOfBirth()+" "+
				c.getAdharNo());

		Plan p=new Plan("123abc","pune","local","100/min","200/min","20/min","25/min","20/min",200,120,200,123,12,234);
			System.out.println(p.getPlanID+"" +p.getPlanCircle+" "+p.getPlanName+" "+p.getLocalCallRate+" "+p.getStdCallRate+" "+p.getLocalSMSRate+" "+p.getStdSMSRate+" "+p.getInternetDataUsageRate+" "+p.getMonthlyRental+p.getFreeLocalCalls
				+" "+p.getFreeStdCalls+p.getFreeLocalSMS+" "+p.getFreeStdSMS+" "+p.getFreeInternetDataUsageUnits);

		PostPaidAccount ppa=new PostPaidAccount(1234567898);
			System.out.println(ppa.getMobileNo);

	}

}
