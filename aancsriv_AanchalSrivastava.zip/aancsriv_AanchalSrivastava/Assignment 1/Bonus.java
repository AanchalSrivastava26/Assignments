
public class Bonus {
	public static void main(String[] args) {
		double bonus, noOfYears=4;
		String designation="analyst ";
		if(noOfYears<=10 &&  noOfYears>=8 && designation=="sr_project_manager")
			System.out.println("bonus ="+10000.0);
		else if(noOfYears<=8 &&  noOfYears>=5 && designation=="project_manager")
			System.out.println("bonus ="+7000.0);
		else if(noOfYears<=5 &&  noOfYears>=4 && designation=="sr_analyst")
			System.out.println("bonus ="+5000.0);
		else
			System.out.println("bonus ="+1000.0);
	}
}
