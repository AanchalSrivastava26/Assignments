public class Factorial{
	public static void main(String[] args){
int f=1,n=6;
for(int i=1;i<=6;i++){
f=f*i;}
System.out.println("factorial of "+n+"="+f);


}	}	
}