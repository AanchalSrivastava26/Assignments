public class SequentialSearch{
	public static void main(String[] args){
		int a[]={1,5,3,4,7},i,j=0,k=11,count=0;
		for(i=0;i<5;i++){
			if(a[i]==k){
				System.out.println("element found at="+(i)+"position");	
				break;
			}
		}
		if(i==5)
			System.out.println("element not found");	
	}
}

