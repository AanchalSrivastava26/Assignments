import java.util.Scanner;
public class QuickSort {
	
    	public static void sort(int[] a){
        		quickSort(a, 0, a.length - 1);
    	}
    	 public static void quickSort(int a[], int l, int h) {
        		int i = l, j = h;
       	 	int temp;
        		int p = a[(l + h) / 2];
 		while (i <= j){
            			while (a[i] < p)
               			i++;
           	 			while (a[j] > p)
                				j--;
            					if (i <= j){
						temp = a[i];
                					a[i] = a[j];
                					a[j] = temp;
				               	i++;
                					j--;
            					}
        				}
 
        				if (l < j)
            					quickSort(a, l, j);
        				if (i < h)
            					quickSort(a, i, h);
    			}
   
    	public static void main(String[] args) {
       		Scanner scan = new Scanner( System.in );        
        		System.out.println("Quick Sort Test\n");
        		int n, i;
        
        		System.out.println("Enter number of integer elements");
        		n = scan.nextInt();
        
        		int a[] = new int[ n ];
        
        		System.out.println("\nEnter "+ n +" integer elements");
        		for (i = 0; i < n; i++)
            		a[i] = scan.nextInt();
        
        		sort(a);
        
        		System.out.println("\nElements after sorting ");        
        		for (i = 0; i < n; i++)
            		System.out.print(a[i]+" ");            
        		System.out.println();            
    	}    
}