public class ArrangeNumber{

	public static void main(String[] args){
		int a[]={7,6,0,0,3,9},num=760039;
		int b[]=new int[10];

		int i,j;
		System.out.println("largest number");
		for(i=0;i<6;i++){
			for(j=i+1;j<6;j++){
			
				if(a[i]<a[j]){
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		for(i=0;i<6;i++)
			System.out.print(a[i]);	
		System.out.println("\n"+"smallest number");
		while(num>0){
			int d=num%10;
			b[d]++;
			num=num/10;
		}
		int result=0;
		for(i=1;i<=9;i++){
			if(b[i]!=0){
				result=i;
				b[i]--;
				break;
			}
		}
		for(i=0;i<=9;i++){
			while(b[i]--!=0)
				result=result*10+i;
		}
		System.out.print(result);	
	}
}