public class OccurenceArray {
	public static void main(String[] args){
		int a[]={1,2,3,3,3,5,6,5,1},i,j,f=-1;
		int b[]=new int[9];
			for(i=0;i<9;i++){
				int count=1;
				for(j=i+1;j<9;j++){
					if(a[i]==a[j]){
						count++;
						b[j]=f;
					}
				}
				if(b[i]!=f)
					b[i]=count;
			}
			for(i=0;i<9;i++){
				if(b[i]!=f)
					System.out.println("occurence of  "+a[i]+"="+b[i]);
			}
	}
}
	