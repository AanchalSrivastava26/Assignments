public class InsertionSort{
	public static void main(String[] args){
		int a[]={1,5,3,4,7},i,j,k;
		for(i=1;i<5;i++){
			k=a[i];
			j=i-1;
				while(j>=0 && a[j]>k){
					a[j+1]=a[j];
					j=j-1;
				}
			a[j+1]=k;
		}
		for(i=0;i<5;i++){
			System.out.println(a[i]);	
		}
	}
}
