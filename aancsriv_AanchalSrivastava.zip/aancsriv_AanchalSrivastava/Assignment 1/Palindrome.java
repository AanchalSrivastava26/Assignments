public class Palindrome{
	public static void main(String[] args){
	int n=123,sum=0,r,temp=n;
	while(n>0){
	sum=sum*10+n%10;
	n=n/10;
	}
	if(sum==temp)
	System.out.println("Palindrome");
	else
    System.out.println("not Palindrome");
	
		
	}}
