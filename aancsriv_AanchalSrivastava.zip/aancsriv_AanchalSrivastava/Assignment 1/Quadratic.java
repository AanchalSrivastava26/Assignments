import java.lang.*;
public class Quadratic {
	public static void main(String[] args) {
		String q="ax^2+bx+c";
		double a=2,b=4,c=1;
		double root1,root2,r,i;
		double d=b*b-4*a*c;
		if(d>0) {
			root1=(-b+Math.sqrt(d)/(2*a));
			root2=(-b-Math.sqrt(d))/(2*a);
			System.out.format("first root  ="+root1);
			System.out.format("second root  ="+root2);
		}
		else if(d==0) {
			root1=root2=(-b+Math.sqrt(d))/(2*a);
			System.out.format("first root  ="+root1);
			System.out.format("second root  ="+root2);
		}
		else {
			r=-b/(2*a);
			i=Math.sqrt(-d)/(2*a);
			System.out.format("roots are ="+r,i);
		}

	}

}