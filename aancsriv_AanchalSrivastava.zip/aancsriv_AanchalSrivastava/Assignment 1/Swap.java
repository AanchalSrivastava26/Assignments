public class Swap{
	public static void main(String[] args){
		int n1=0,n2=1;
		System.out.println("numbers before swap="+n1+" "+n2);
		n1=n1+n2;
		n2=n1-n2;
		n1=n1-n2;
		System.out.println("numbers after swap= "+n1+" "+n2);	
	}	
}