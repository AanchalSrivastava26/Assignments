public class Hcf_Lcm{
	public static void main(String[] args){
		int n1=6,n2=15,i,hcf=0;
		for(i=1;i<=n1 && i<=n2;i++){
			if(n1%i==0 && n2%i==0)
				hcf=i;
		}
			System.out.println("hcf ="+hcf);
			System.out.println("lcm ="+((n1*n2)/hcf));				
	}
}

