public class BinaryToDecimal {
	public static void main(String[] args) {
		int a[]=new int[10];
		int n=1111,sum=0;
		double r,p=0;
		while (n>0) {
			r=n%10;
			sum=(int) (sum+(r*Math.pow(2,p)));
			p++;
			n=n/10;
		}
		System.out.print(sum);
	}
}
