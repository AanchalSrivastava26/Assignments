public class DecimalToBinary {
	public static void main(String[] args) {
		int a[]=new int[10];
		int n=14,q,r,num=0,sum=0;
		while (n>0) {
			r=n%2;
			a[num++]=r;
			n=n/2;
		}
		for(int i=num-1;i>=0;i--)
			System.out.print(a[i]);
	}
}
