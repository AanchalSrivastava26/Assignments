public class ArrangeArray{

	public static void main(String[] args){
		int a[]={1,2,3,4,5,6,7,8,9,10};
		int b[]=new int[10];
		int i,count=1,flag=10;
		for(i=0;i<10;i++){
			if(a[i]%2==0){
				b[i]=count;
				count++;
			}
			else{
				b[i]=flag;
				flag--;
			}		
			System.out.print(b[i]+" ");
		}
	}
}